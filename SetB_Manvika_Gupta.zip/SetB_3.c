#include <stdio.h>
void reverseBits(int);
int main()
{
    int i,num;
    int num_bits[20];
    printf("Enter the number:");
    scanf("%d",&num);
   reverseBits(num);
      return 0;
}

void reverseBits(int n)
{
   int i,c=0,a[20];
    for(i=0;n>0;i++)    
{    
a[i]=n%2;    
n=n/2;  
c++;
}    
printf("Binary is: ");
for(i=i-1;i>=0;i--){
printf("%d", a[i]);    
}
printf("\nReverse is: ");
for(i=0;i<c;i++){
    printf("%d",a[i]);
}
    
    

}
