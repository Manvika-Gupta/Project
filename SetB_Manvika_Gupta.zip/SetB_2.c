
#include <stdio.h>
#include <string.h>

int main()
{   
    FILE *fdata;
    char child[100][100],father[100][100],name[100];
    
    if ((fdata = fopen("relations.txt", "r")) == NULL) 
    {
       printf("Error! File can't be opened.");
    }
    
    for(int j=1;j<=5;j++)
    {
       while(fscanf(fdata,"%s %s",child[j],father[j])!=EOF) 
       {
          break;
       }
          
       printf("\n%s %s",child[j],father[j]); 
   }
    printf("\n");
    
    int grandchildren_count=0,fatherPos,i;
    printf("\nEnter the name whose grandchildren you want to find: ");
    scanf("%s",name);
    for(i=1;i<=5;i++)
    {
        if(strcmp(name,father[i])==0)
        {
            fatherPos=i;
            for(int j=1;j<=5;j++)
            {
               if(strcmp(child[fatherPos],father[j])==0)
               {
                 grandchildren_count++;
               }

            }
        }
    }
    
    printf("%s has %d grandchildren\n",name,grandchildren_count);
    return 0;
}



