#include <stdio.h>
int main() 
{
    int l;
       
    printf("Enter the length of string: ");
    scanf("%d",&l);
    char s[l];
    printf("Enter the string: ");
    scanf("%s", s);
    int i=0,flag;
   //l=strlen(s);
   do    
   {
       flag=0;
       for(i=0;i<l-1;i++)
      {
           if(s[i]==s[i+1])
           {
                flag=1;
                for(int j=i;j<l-2;j++)
                     s[j]=s[j+2];
                 l=l-2;
            }
            
       }
        s[l]='\0';
} while(flag==1 && l>0);
if(l!=0)
    printf("%s\n",s);
else  
    printf("Empty String\n");
    return 0;
}
